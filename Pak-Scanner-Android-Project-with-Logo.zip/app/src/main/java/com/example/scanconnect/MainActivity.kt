package com.example.scanconnect

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.OutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private var currentBitmap: Bitmap? = null
    private var currentUri: Uri? = null

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    currentBitmap = BitmapFactory.decodeStream(stream)
                }
                currentUri = uri
                showPreview()
                message("Image loaded. Use B&W or Enhance.")
            } catch (e: Exception) { message("Image open nahi hui: ${e.message}") }
        }
    }

    private val scannerLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            val uri = scan?.pages?.firstOrNull()?.imageUri
            if (uri != null) {
                try {
                    contentResolver.openInputStream(uri)?.use { currentBitmap = BitmapFactory.decodeStream(it) }
                    currentUri = uri
                    showPreview()
                    message("Scan complete. Auto crop/scanner applied.")
                } catch (e: Exception) { message("Scan image load nahi hui.") }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(247, 249, 253))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "ScanConnect"
            textSize = 28f
            setTextColor(Color.rgb(25, 54, 110))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "Offline document scanner • image tools • PDF"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 16)
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            minimumHeight = 240
            setBackgroundColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Camera se scan karein ya gallery se image select karein."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(4, 12, 4, 12)
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 300))
        content.addView(status)
        addButton(content, "📷  Camera Scan / Auto Crop") { startScanner() }
        addButton(content, "🖼  Gallery se image") { galleryPicker.launch("image/*") }
        addButton(content, "⚫  Black & White") { transform("bw") }
        addButton(content, "✨  Extra saaf / Enhance") { transform("enhance") }
        addButton(content, "💾  Gallery mein save") { saveImage() }
        addButton(content, "📄  PDF banayein") { savePdf() }
        addButton(content, "↗  WhatsApp / Bluetooth / Share") { shareImage() }
        addButton(content, "💬  Online Chat & Calls setup") {
            message("Online chat/calls ke liye Firebase + WebRTC backend aur login provider setup chahiye. SETUP.md dekhein.")
            startActivity(Intent(this, SetupInfoActivity::class.java))
        }
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 4
        })
    }

    private fun startScanner() {
        try {
            val options = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(20)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            GmsDocumentScanning.getClient(options).getStartScanIntent(this)
                .addOnSuccessListener { sender -> scannerLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(sender).build()) }
                .addOnFailureListener { e -> message("Scanner start nahi hua: ${e.localizedMessage ?: "Google Play services check karein"}") }
        } catch (e: Exception) { message("Camera scanner unavailable. Gallery option use karein.") }
    }

    private fun transform(mode: String) {
        val source = currentBitmap
        if (source == null) { message("Pehle camera scan ya gallery se image select karein."); return }
        try {
            val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(source.width * source.height)
            source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
            for (i in pixels.indices) {
                val c = pixels[i]
                var r = Color.red(c); var g = Color.green(c); var b = Color.blue(c)
                if (mode == "bw") {
                    val gray = (0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)
                    // Slight contrast boost for document readability.
                    val v = (((gray - 128) * 1.45) + 128).toInt().coerceIn(0, 255)
                    r = v; g = v; b = v
                } else {
                    // Contrast and brightness boost; lightweight offline enhancement.
                    r = (((r - 128) * 1.28) + 137).toInt().coerceIn(0, 255)
                    g = (((g - 128) * 1.28) + 137).toInt().coerceIn(0, 255)
                    b = (((b - 128) * 1.28) + 137).toInt().coerceIn(0, 255)
                }
                pixels[i] = Color.argb(Color.alpha(c), r, g, b)
            }
            output.setPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
            currentBitmap = output
            showPreview()
            message(if (mode == "bw") "Black & White applied." else "Contrast/brightness enhancement applied.")
        } catch (e: Exception) { message("Image process nahi hui: ${e.localizedMessage}") }
    }

    private fun showPreview() {
        preview.setImageBitmap(currentBitmap)
    }

    private fun saveImage() {
        val bitmap = currentBitmap ?: run { message("Pehle image select karein."); return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ScanConnect_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScanConnect")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Gallery location create nahi hui")
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            message("Image Gallery/Pictures/ScanConnect mein save ho gayi.")
        } catch (e: Exception) { message("Save failed: ${e.localizedMessage}") }
    }

    private fun savePdf() {
        val bitmap = currentBitmap ?: run { message("Pehle image select karein."); return }
        var document: PdfDocument? = null
        try {
            document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val scale = minOf(555f / bitmap.width, 790f / bitmap.height)
            val w = (bitmap.width * scale).toInt()
            val h = (bitmap.height * scale).toInt()
            val left = (595 - w) / 2f
            val top = (842 - h) / 2f
            page.canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, w, h, true), left, top, Paint(Paint.FILTER_BITMAP_FLAG))
            document.finishPage(page)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "ScanConnect_${System.currentTimeMillis()}.pdf")
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH, "Download")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("PDF location create nahi hui")
            contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
            message("PDF Downloads folder mein save ho gayi.")
        } catch (e: Exception) { message("PDF failed: ${e.localizedMessage}") }
        finally { document?.close() }
    }

    private fun shareImage() {
        val bitmap = currentBitmap ?: run { message("Pehle image select karein."); return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ScanConnect_share_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScanConnect")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Share file create nahi hui")
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "WhatsApp, Bluetooth ya app choose karein"))
        } catch (e: Exception) { message("Share failed: ${e.localizedMessage}") }
    }

    private fun message(text: String) {
        status.text = text
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }
}
